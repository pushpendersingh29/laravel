<!DOCTYPE html>
<html>
<head>
	<title>Login</title>
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/bootstrap.min.css')); ?>">
</head>
<body>
	<div class="container-fluid">
		<div class="row"  style="margin:5px;">
			<div class="col-md-11">
				<h4>Dashboard</h4>
			</div>
			<div class="col-md-1">
				<a href="<?php echo e(route('auth.logout')); ?>" class="btn btn-danger">Logout</a>
			</div>
		</div>
		<hr>
         <div class="row">
            <div class="col-md-12">
                        <?php
                            if ($LoggedUserInfo['role'] == 1) {
                                echo '<a href="/admin/students" class="btn">Students List</a><hr>';
                            }
                        ?>
                       
                       <h2 class="text-center">Your Profile</h2>
                   <table class="table table-hover table-bordered">
	                    <tr>
	                       <th>Name</th>
	                       <td><?php echo e($LoggedUserInfo['first_name']); ?> <?php echo e($LoggedUserInfo['last_name']); ?></td>
	                    </tr>
                       	<tr>
                            <th>Email</th>
                            <td><?php echo e($LoggedUserInfo['email']); ?></td>
                        </tr>
                        	<tr>
                            <th>Mobile No.</th>
                            <td><?php echo e($LoggedUserInfo['mobile']); ?></td>
                        </tr>
                        <tr>
                            <th>Role</th>
                            <td>
                                <?php
                					if ($LoggedUserInfo['role'] == 1) {
                						echo "Teacher";
                					}
                					else{
                						echo "Student";
                					} 
                                ?>
                             </td>
                        </tr>
                   </table>

                   
            </div>
         </div>
    </div>

</body>
</html><?php /**PATH E:\laravel\praxiv\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>