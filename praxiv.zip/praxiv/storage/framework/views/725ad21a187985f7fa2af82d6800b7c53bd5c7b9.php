<!DOCTYPE html>
<html>
<head>
	<title>Login</title>
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/bootstrap.min.css')); ?>">
</head>
<body>
	<div class="container-fluid">
        <div class="row"  style="margin:5px;">
            <div class="col-md-11">
                <h4>Dashboard</h4>
            </div>
            <div class="col-md-1">
                <a href="<?php echo e(route('auth.logout')); ?>" class="btn btn-danger">Logout</a>
            </div>
        </div> 
        <hr> 
        <div class="row">
            <div class="col-md-12">
                <?php
                    if ($LoggedUserInfo['role'] == 1) {
                        echo '<a href="/admin/dashboard" class="btn">Your Profile</a><hr>';
                     }
                ?>
                <h2 class="text-center">Students List</h2>
                <table class="table table-bordered text-center">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Name</th>
                            <th>Email</th>
                            <th>Mobile</th>
                        </tr>
                    </thead>
                    <?php
                        $i=1;
                    ?>
                   <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                   <tbody>
                    <tr>
                        <td><?php echo e($i); ?></td>
                        <td><?php echo e($user->first_name); ?> <?php echo e($user->last_name); ?></td>
                        <td><?php echo e($user->email); ?></td>
                        <td><?php echo e($user->mobile); ?></td>
                    </tr>
                    <?php $i++; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>

                </table>
            </div>
        </div>

    </div>

</body>
</html><?php /**PATH E:\laravel\praxiv\resources\views/admin/students.blade.php ENDPATH**/ ?>