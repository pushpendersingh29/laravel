<!DOCTYPE html>
<html>
<head>
	<title>Register New User</title>
</head>
<body>
	<h1 style="margin-left: 40%">Add New User</h1><hr>
	<a href="view">View Users</a>
	<table border="1" style="margin-left: 40%">
		<form action="add" method="POST">
			<?php echo csrf_field(); ?>
			<tr>
				<th>First Name :</th>
				<td><input type="text" name="first_name" placeholder="Enter first name"></td>
			</tr>
			<tr>
				<th>Last Name :</th>
				<td><input type="text" name="last_name" placeholder="Enter last name"></td>
			</tr>
			<tr>
				<th>Mobile No.:</th>
				<td><input type="text" name="mobile" placeholder="Enter mobile number"></td>
			</tr>
			<tr>
				<th>Password :</th>
				<td><input type="text" name="password" placeholder="Enter first name"></td>
			</tr>
			<tr>
				<th>Confirm Password :</th>
				<td><input type="text" name="cpassword" placeholder="Enter first name"></td>
			</tr>
			<tr>
				<th>Select Role :</th>
				<td><select name="role">
					<option value="1">Teacher</option>
					<option value="0">Student</option>
				</select></td>
			</tr>
			<tr>
				<th></th>
				<td><button type="submit">Register</button></td>
			</tr>
		</form>
	</table>


</body>
</html><?php /**PATH E:\laravel\praxiv\resources\views/addusers.blade.php ENDPATH**/ ?>