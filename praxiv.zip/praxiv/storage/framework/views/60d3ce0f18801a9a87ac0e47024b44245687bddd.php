<!DOCTYPE html>
<html>
<head>
	<title>Login</title>
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/bootstrap.min.css')); ?>">
</head>
<body>
	<div class="container">
		<div class="row">
			<div class="col-md-12">
				<h4 style="margin-top: 50px;" class="text-center">Register</h4>
				<hr>
			</div>
		</div>
		
		<div class="row">
			<div class="col-md-12">
				<?php if(Session::get('success')): ?>
		             <div class="alert alert-success">
		                <?php echo e(Session::get('success')); ?>

		             </div>
		           <?php endif; ?>

		           <?php if(Session::get('fail')): ?>
		             <div class="alert alert-danger">
		                <?php echo e(Session::get('fail')); ?>

		             </div>
		           <?php endif; ?>
			</div>
		</div>
		<div class="row">

			<div class="col-md-6 m-auto d-block" >
				
				<form action="<?php echo e(route('auth.save')); ?>" method="post">

					

					<?php echo csrf_field(); ?>
					<div class="form-group">
						<label>First Name</label>
						<input type="text" class="form-control" name="first_name" placeholder="Enter first name" value="<?php echo e(old('first_name')); ?>">
						<span class="text-danger"><?php $__errorArgs = ['first_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span>
					</div>
					<div class="form-group">
						<label>Last Name</label>
						<input type="text" class="form-control" name="last_name" placeholder="Enter last name" value="<?php echo e(old('last_name')); ?>">
						<span class="text-danger"><?php $__errorArgs = ['last_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span>
					</div>
					<div class="form-group">
						<label>Email</label>
						<input type="text" class="form-control" name="email" class="form-control" placeholder="Enter Email ID" value="<?php echo e(old('email')); ?>">
						<span class="text-danger"><?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span>
					</div>
			</div>
			<div class="col-md-6 m-auto d-block" >
					<div class="form-group">
						<label>Mobile</label>
						<input type="text" class="form-control" name="mobile" placeholder="Enter mobile number" value="<?php echo e(old('mobile')); ?>">
						<span class="text-danger"><?php $__errorArgs = ['mobile'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span>
					</div>
					<div class="form-group">
						<label>Password</label>
						<input type="password" class="form-control" name="password" class="form-control" placeholder="Enter Password" value="<?php echo e(old('password')); ?>">
						<span class="text-danger"><?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span>
					</div>
					<div class="form-group">
						<label>Select Role</label>
						<select name="role" class="form-control">
							<option value="">Select Role</option>
							<option value="1">Teacher</option>
							<option value="0">Student</option>	
						</select><span class="text-danger"><?php $__errorArgs = ['role'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span>
					</div>
					
			</div>
			<button type="submit" class="btn btn-block btn-primary">Login</button>
					<span>I have already an account, <a href="<?php echo e(route('auth.login')); ?>">Login Now</a></span>
				</form>
			</div>
		</div>
	</div>

</body>
</html><?php /**PATH E:\laravel\praxiv\resources\views/auth/register.blade.php ENDPATH**/ ?>