<!DOCTYPE html>
<html>
<head>
	<title>View Users</title>
<html>
<head>
	<title>Register New User</title>
</head>
<body>
	<h1 style="margin-left: 40%">View Users</h1><a href="add">Add User</a><hr>

	<table border="1" style="margin-left: 30%">
		<tr>
			<th>S.No.</th>
			<th>Name</th>
			<th>Mobile No.</th>
			<th>Password</th>
			<th>C Password</th>
			<th>Role</th>
			<th colspan="2">Action</th>
		</tr>
		<?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<tr>
			<td><?php echo e($user['id']); ?></td>
			<td><?php echo e($user['first_name']); ?> <?php echo e($user['last_name']); ?></td>
			<td><?php echo e($user['mobile']); ?></td>
			<td><?php echo e($user['password']); ?></td>
			<td><?php echo e($user['cpassword']); ?></td>
			<td>
				<?php
					if ($user['role'] == 1) {
						echo "Teacher";
					}
					else{
						echo "Student";
					}
				?>
			</td>
			<td><a href="<?php echo e('edit/'.$user['id']); ?>">Edit</a></td>
			<td><a href="<?php echo e('delete/'.$user['id']); ?>" onclick="return confirm('Do you want to delete this record!')">Delete</a></td>
		</tr>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</table>




</body>
</html></title>
</head>
<body>

</body>
</html><?php /**PATH E:\laravel\praxiv\resources\views/viewusers.blade.php ENDPATH**/ ?>