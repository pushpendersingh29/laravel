<!DOCTYPE html>
<html>
<head>
	<title>Login</title>
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/bootstrap.min.css')); ?>">
</head>
<body>
	<div class="container">
		<div class="row">
			<div class="col-md-4 m-auto d-block" >
				<h4 style="margin-top: 50px;" class="text-center">Login</h4>
				<hr>
				<form action="<?php echo e(route('auth.check')); ?>" method="post">

					<?php if(Session::get('fail')): ?>
		             <div class="alert alert-danger">
		                <?php echo e(Session::get('fail')); ?>

		             </div>
		           <?php endif; ?>

					<?php echo csrf_field(); ?>
					<div class="form-group">
						<label>Email</label>
						<input type="text" name="email" class="form-control" placeholder="Enter Email ID" value="<?php echo e(old('email')); ?>">
						<small class="text-danger"><?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></small>
					</div>
					<div class="form-group">
						<label>Password</label>
						<input type="password" name="password" class="form-control" placeholder="Enter Password">
						<small class="text-danger"><?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></small>
					</div>
					<button type="submit" class="btn btn-block btn-primary">Login</button>
					<br>
					<span>I don't have account, <a href="<?php echo e(route('auth.register')); ?>">Create New</a></span>
				</form>
			</div>
		</div>
	</div>

</body>
</html><?php /**PATH E:\laravel\praxiv\resources\views/auth/login.blade.php ENDPATH**/ ?>