<!DOCTYPE html>
<html>
<head>
	<title>Update User</title>
</head>
<body>
	<h1 style="margin-left: 40%">Update User</h1><hr>
	<a href="view">View Users</a>
	<table border="1" style="margin-left: 40%">
		<form action="/edit" method="POST">
			<?php echo csrf_field(); ?>
			<input type="hidden" name="id" value="<?php echo e($data['id']); ?>">
			<tr>
				<th>First Name :</th>
				<td><input type="text" name="first_name" value="<?php echo e($data['first_name']); ?>"></td>
			</tr>
			<tr>
				<th>Last Name :</th>
				<td><input type="text" name="last_name" value="<?php echo e($data['last_name']); ?>"></td>
			</tr>
			<tr>
				<th>Mobile No.:</th>
				<td><input type="text" name="mobile" value="<?php echo e($data['mobile']); ?>"></td>
			</tr>
			<tr>
				<th>Password :</th>
				<td><input type="text" name="password" value="<?php echo e($data['password']); ?>"></td>
			</tr>
			<tr>
				<th>Confirm Password :</th>
				<td><input type="text" name="cpassword" value="<?php echo e($data['cpassword']); ?>"></td>
			</tr>
			<tr>
				<th>Select Role :</th>
				<td><select name="role">
					<option value="1">Teacher</option>
					<option value="0">Student</option>
				</select></td>
			</tr>
			<tr>
				<th></th>
				<td><button type="submit">Update</button></td>
			</tr>
		</form>
	</table>


</body>
</html><?php /**PATH E:\laravel\praxiv\resources\views/edituser.blade.php ENDPATH**/ ?>