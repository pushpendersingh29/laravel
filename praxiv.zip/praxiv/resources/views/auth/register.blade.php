<!DOCTYPE html>
<html>
<head>
	<title>Login</title>
	<link rel="stylesheet" type="text/css" href="{{ asset('css/bootstrap.min.css') }}">
</head>
<body>
	<div class="container">
		<div class="row">
			<div class="col-md-12">
				<h4 style="margin-top: 50px;" class="text-center">Register</h4>
				<hr>
			</div>
		</div>
		
		<div class="row">
			<div class="col-md-12">
				@if(Session::get('success'))
		             <div class="alert alert-success">
		                {{ Session::get('success') }}
		             </div>
		           @endif

		           @if(Session::get('fail'))
		             <div class="alert alert-danger">
		                {{ Session::get('fail') }}
		             </div>
		           @endif
			</div>
		</div>
		<div class="row">

			<div class="col-md-6 m-auto d-block" >
				
				<form action="{{ route('auth.save') }}" method="post">

					

					@csrf
					<div class="form-group">
						<label>First Name</label>
						<input type="text" class="form-control" name="first_name" placeholder="Enter first name" value="{{ old('first_name') }}">
						<span class="text-danger">@error('first_name'){{ $message }} @enderror</span>
					</div>
					<div class="form-group">
						<label>Last Name</label>
						<input type="text" class="form-control" name="last_name" placeholder="Enter last name" value="{{ old('last_name') }}">
						<span class="text-danger">@error('last_name'){{ $message }} @enderror</span>
					</div>
					<div class="form-group">
						<label>Email</label>
						<input type="text" class="form-control" name="email" class="form-control" placeholder="Enter Email ID" value="{{ old('email') }}">
						<span class="text-danger">@error('email'){{ $message }} @enderror</span>
					</div>
			</div>
			<div class="col-md-6 m-auto d-block" >
					<div class="form-group">
						<label>Mobile</label>
						<input type="text" class="form-control" name="mobile" placeholder="Enter mobile number" value="{{ old('mobile') }}">
						<span class="text-danger">@error('mobile'){{ $message }} @enderror</span>
					</div>
					<div class="form-group">
						<label>Password</label>
						<input type="password" class="form-control" name="password" class="form-control" placeholder="Enter Password" value="{{ old('password') }}">
						<span class="text-danger">@error('password'){{ $message }} @enderror</span>
					</div>
					<div class="form-group">
						<label>Select Role</label>
						<select name="role" class="form-control">
							<option value="">Select Role</option>
							<option value="1">Teacher</option>
							<option value="0">Student</option>	
						</select><span class="text-danger">@error('role'){{ $message }} @enderror</span>
					</div>
					
			</div>
			<button type="submit" class="btn btn-block btn-primary">Login</button>
					<span>I have already an account, <a href="{{ route('auth.login') }}">Login Now</a></span>
				</form>
			</div>
		</div>
	</div>

</body>
</html>