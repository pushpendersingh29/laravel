<!DOCTYPE html>
<html>
<head>
	<title>Login</title>
	<link rel="stylesheet" type="text/css" href="{{ asset('css/bootstrap.min.css') }}">
</head>
<body>
	<div class="container">
		<div class="row">
			<div class="col-md-4 m-auto d-block" >
				<h4 style="margin-top: 50px;" class="text-center">Login</h4>
				<hr>
				<form action="{{ route('auth.check') }}" method="post">

					@if(Session::get('fail'))
		             <div class="alert alert-danger">
		                {{ Session::get('fail') }}
		             </div>
		           @endif

					@csrf
					<div class="form-group">
						<label>Email</label>
						<input type="text" name="email" class="form-control" placeholder="Enter Email ID" value="{{ old('email') }}">
						<small class="text-danger">@error('email'){{ $message }} @enderror</small>
					</div>
					<div class="form-group">
						<label>Password</label>
						<input type="password" name="password" class="form-control" placeholder="Enter Password">
						<small class="text-danger">@error('password'){{ $message }} @enderror</small>
					</div>
					<button type="submit" class="btn btn-block btn-primary">Login</button>
					<br>
					<span>I don't have account, <a href="{{ route('auth.register') }}">Create New</a></span>
				</form>
			</div>
		</div>
	</div>

</body>
</html>