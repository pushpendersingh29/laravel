<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\User;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;

class MainController extends Controller
{
    function login(){
        return view('auth.login');
    }

    function register(){
    	return view('auth.register');
    }

    function save(Request $request){
    	// return $request->input();
    	// Validate form

    	$request->validate([
    		'first_name'=>'required',
    		'last_name'=>'required',
    		'email'=>'required|email|unique:users',
    		'mobile'=>'required|digits:10|unique:users',
    		'password'=>'required|min:5|max:12',
    		'role' => 'required'
    	]);

    	//insert data into database through register form

    	$user = new User;
    	$user->first_name = $request->first_name;
    	$user->last_name = $request->last_name;
    	$user->email = $request->email;
    	$user->mobile = $request->mobile;
    	$user->password = Hash::make($request->password);
    	$user->role = $request->role;

    	$save = $user->save();

    	if($save){
            return back()->with('success','Your account has been created successfully');
         }else{
             return back()->with('fail','Something went wrong, try again later');
         }
    }


    function check(Request $request){
    	//return $request->input();
    	// validate 
    	$request->validate([
    		'email'=>'required|email',
    		'password'=>'required|min:5|max:12'
    	]);

    	$userInfo = User::where('email','=', $request->email)->first();

    	 if(!$userInfo){
            return back()->with('fail','Incorrect email address');
        }
        else{
            //check password
            if(Hash::check($request->password, $userInfo->password)){
                $request->session()->put('LoggedUser', $userInfo->id);
                return redirect('admin/dashboard');

            }
            else{
                return back()->with('fail','Incorrect password');
            }
        }   
    }

    function logout(){
        if(session()->has('LoggedUser')){
            session()->pull('LoggedUser');
            return redirect('/auth/login');
        }
    }

    function dashboard(){
        $data = ['LoggedUserInfo'=>User::where('id','=', session('LoggedUser'))->first()];
        return view('admin.dashboard', $data);
    }

    function students(){
    	$res = ['LoggedUserInfo'=>User::where('id','=', session('LoggedUser'))->first()];
    	$data =  DB::table('users')
    					->where('role','=',0)
    					->get();
    	return view('admin.students',['data'=>$data],$res);
    }

}
